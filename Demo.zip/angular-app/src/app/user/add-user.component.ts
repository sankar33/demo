import {Component} from '@angular/core';
import {Router} from '@angular/router';
import {
    ReactiveFormsModule,
    FormsModule,
    FormGroup,
    FormControl,
    Validators,
    FormBuilder
} from '@angular/forms';

import {User} from '../models/user.model';
import {UserService} from './user.service';

@Component({
  templateUrl: './add-user.component.html'
})
export class AddUserComponent {

  myform: FormGroup;
  user: User = new User();

  constructor(private router: Router, private userService: UserService) {

  }

  onSubmit() {
    if (this.myform.valid) {
      console.log("Form Submitted!");
    }
  }

  createUser(): void {
    this.userService.createUser(this.user)
      .subscribe(data => {
        this.router.navigate(['/users']);
      });
  }

}
